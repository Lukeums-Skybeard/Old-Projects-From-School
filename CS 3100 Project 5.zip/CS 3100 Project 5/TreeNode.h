#pragma once
using namespace std;

template <class KeyType, class ItemType>
class TreeNode
{
private:
	ItemType item;
	KeyType  key;
	TreeNode* left;
	TreeNode* right;
public:
	TreeNode();
	TreeNode(KeyType newKey, ItemType newItem);
	TreeNode<KeyType, ItemType>* Left();
	TreeNode<KeyType, ItemType>* Right();
	KeyType getKey();
	ItemType getItem();
	void setLeft(TreeNode* entry);
	void setRight(TreeNode* entry);
	void setValue(KeyType newKey, ItemType newItem);
};


template <class KeyType, class ItemType>
TreeNode<KeyType, ItemType>::TreeNode()
{
	left = nullptr;
	right = nullptr;
}

template <class KeyType, class ItemType>
TreeNode<KeyType, ItemType>::TreeNode(KeyType newKey, ItemType newItem)
{
	item = newItem;
	key = newKey;
	left = nullptr;
	right = nullptr;
}

template <class KeyType, class ItemType>
TreeNode<KeyType, ItemType>* TreeNode<KeyType, ItemType>::Left()
{
	return left;
}

template <class KeyType, class ItemType>
TreeNode<KeyType, ItemType>* TreeNode<KeyType, ItemType>::Right()
{
	return right;
}

template <class KeyType, class ItemType>
ItemType TreeNode<KeyType, ItemType>::getItem()
{
	return item;
}

template <class KeyType, class ItemType>
KeyType TreeNode<KeyType, ItemType>::getKey()
{
	return key;
}

template <class KeyType, class ItemType>
void TreeNode<KeyType, ItemType>::setLeft(TreeNode* node)
{
	left = node;
}

template <class KeyType, class ItemType>
void TreeNode<KeyType, ItemType>::setRight(TreeNode* node)
{
	right = node;
}

template <class KeyType, class ItemType>
void TreeNode<KeyType, ItemType>::setValue(KeyType newKey, ItemType newItem)
{
	item = newItem;
	key = newKey;
}