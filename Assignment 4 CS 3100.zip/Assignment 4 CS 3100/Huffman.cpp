#include <iostream>
#include <fstream>
#include <string>
#include <queue>
using namespace std;

#include "bitops.h"
#include "huff.h"
#include "unhuff.h"

int main()
{
	string choice;
	while (true) {
		cout << "Please choose (huff/unhuff/quit): ";
		cin >> choice;

		if (choice.compare("huff") == 0) {
			string filename = "C:\\Users\\Schuyler\\Desktop\\test.txt";
			
			string encodefile = "C:\\Users\\Schuyler\\Desktop\\Encodedfile.txt";
			// cout << "Enter message file: ";
			// cin >> filename;
			huff huffy(filename,encodefile);

			// cout << "Enter encoded message file: ";
			// cin >> filename;
			//huffy.SaveEncodeMessage("encodedMsg.txt");
		}
		else if (choice.compare("unhuff") == 0) {
			string encodedfile = "C:\\Users\\Schuyler\\Desktop\\Encodedfile.txt";
			// cout << "Enter encoded message file: ";
			// cin >> filename;
			unhuff unhuffy(encodedfile);

		}
		else if (choice.compare("quit") == 0) {
			break;
		}
	}

	return 0;
}