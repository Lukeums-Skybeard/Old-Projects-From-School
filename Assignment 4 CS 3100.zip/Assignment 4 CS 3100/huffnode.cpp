#include "huffnode.h"

huffnode::huffnode()
{
	letter = NOT_A_LETTER;
	zero = nullptr;
	one = nullptr;
	weight = 0;
}

bool huffnode::isLeaf(huffnode* node)
{
	return node->one == nullptr && node->zero == nullptr;
}