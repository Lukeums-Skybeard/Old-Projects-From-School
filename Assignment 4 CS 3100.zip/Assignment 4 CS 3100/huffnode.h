#ifndef _HUFFNODE_H
#define _HUFFNODE_H

#include "globals.h"

class huffnode
{
public:
	huffnode();	
	huffnode* zero;
	huffnode* one;
	int letter;
	int weight;
	static bool isLeaf(huffnode * node);
};

#endif