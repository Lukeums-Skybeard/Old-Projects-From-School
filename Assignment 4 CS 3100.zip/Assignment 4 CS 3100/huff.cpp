#include "huff.h"

struct compare
{
	bool operator()(const huffnode* l, const huffnode* r)
	{
		return l->weight > r->weight;
	}
};

// Creates tree from a file containing orginal message.
huff::huff(string msgfile,string encodedfile)
{
	fstream file;
	msgFile = msgfile;
	string huffsent="", tempstr, bitpath;
	int counters[257];
	int intofcharacter;
	int j = 0;
	lookupTable = new unordered_map<int, string>;
	huffnode *node;
	priority_queue<huffnode*, vector<huffnode*>, compare>* pq = new priority_queue<huffnode*, vector<huffnode*>, compare>;


	// The file reading and tree building stuff goes here

	file.open(msgFile);
	// read in the sentence from the file

	while (!file.eof())
	{
		file >> tempstr;
		//cout << tempstr<<endl;
		
		if (huffsent != "") {


			huffsent = huffsent + " " + tempstr;
		}
		else
		{
			huffsent = tempstr;
		}
	}

	//cout << huffsent << endl;
	//set the counters to zero
	for (int i = 0; i < 258; i++)
	{
		counters[i] = 0;

	}
	//this is where i convert the ASCII equivalent of the strings and add the weights

	for (int i = 0; i < huffsent.size(); i++)
	{
		intofcharacter = int(huffsent[i]);

		counters[intofcharacter]=counters[intofcharacter]+1;
		//cout << intofcharacter << " "<< counters[intofcharacter] << endl;
	}

	//create huffnodes
	for (int i = 0; i < 258; i++)
	{
		if (counters[i] != 0)
		{
			node = new huffnode();
			node->letter = i;
			node->weight = counters[i];

			pq->push(node);
		}
	}
	//this is the test cases 
	/*
	while (!pq->empty())
	{
		node = pq->top();
		cout << node->letter << " ";
		cout << node->weight << endl;
		pq->pop();

	}
	I had to comment this out so the program would work
	*/
	

	//now i need to create the tree in the priority queue
	// Makes a couple of new pointers to huffnodes
	while (pq->size() != 1)
	{
		huffnode* testNode1 = new huffnode();

		testNode1 = pq->top();

		pq->pop();
		huffnode* testNode2 = new huffnode();
		testNode2 = pq->top();

		pq->pop();

		// peek at the top value

		huffnode*combinedNode = new huffnode();
		combinedNode->letter = NOT_A_LETTER;

		combinedNode->weight = testNode1->weight + testNode2->weight;

		if (testNode1->letter < testNode2->letter)
		{
			combinedNode->zero = testNode1;
			combinedNode->one = testNode2;
		}
		else
		{
			combinedNode->zero = testNode1;
			combinedNode->one = testNode2;

		}
		pq->push(combinedNode);

	}
	node = pq->top();
	CreateLookupTable(node, bitpath, * lookupTable);
	node = pq->top();
	SaveEncodeMessage(encodedfile,*lookupTable, node);
}

void huff::CreateLookupTable(huffnode * node, string bitpath,unordered_map<int, string> lookupTable )
{
	
	// Base case... if the node is null just return
	//if (node == nullptr)
		//return;
	
	// If the node is a leaf {
	//    insert this node letter and bitpath to the lookupTable

	if (node->isLeaf(node))
	{
		pair<int, string> entry(node->letter, bitpath);
		//cout << node->letter << " " << bitpath << endl;
		lookupTable.insert(entry);

	}
	if (node->zero != NULL)
	{
		bitpath = bitpath + "0";
		CreateLookupTable(node->zero, bitpath, lookupTable);
		//cout << node->letter << " " << bitpath << endl;
	}
	if (node->one != NULL)
	{
		bitpath = bitpath + "1";
		CreateLookupTable(node->one, bitpath, lookupTable);
		//cout << node->letter << " " << bitpath << endl;
	}
	// } else {
	//    Create lookup table for the "one"  branch (Add "1" to the bitpath)
	//	  Create lookup table for the "zero" branch (Add "0" to the bitpath)
	// }
}

void huff::SaveEncodeMessage(string encodedFile,unordered_map<int, string> lookupTable, huffnode *node)
{
	obstream output;
	output.open(encodedFile);

	if (node->isLeaf(node))
	{
		//do nothing
	}
	cout << "Writing frequencies: " << endl;
	// Write frequencies to the file:
	// HINT: output.writebits(32, 314); writes the integer 314 as a 32 byte to the file

	output.writebits(32, node->weight);
	SaveEncodeMessage(encodedFile, lookupTable, node->zero);
	
	SaveEncodeMessage(encodedFile, lookupTable, node->one);
	

	cout << "Writing encoded data: " << endl;
	// Write the binary data to the file
	// output.writebits(1, 1); // this writes the single bit 1 to the file
	// output.writebits(1, 0); // this writes the single bit 0 to the file
	for (int i = 0; i < lookupTable.at(node->letter).length(); i++)
	{
		if (lookupTable.at(node->letter).compare("0"))
		{
			output.writebits(1, 0);
		}

		if (lookupTable.at(node->letter).compare("0"));
		{
			output.writebits(1, 1);
		}
	}
	output.close();
}