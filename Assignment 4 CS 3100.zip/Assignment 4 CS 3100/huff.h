#pragma once
#include <iostream>
#include <fstream>
#include<string>
#include<vector>
#include<queue>
#include<unordered_map>
using namespace std;

#include "bitops.h"
#include "globals.h"
#include "huffnode.h"

class huff
{
public:
	huff(string msgfile, string encodedfile);
	void SaveEncodeMessage(string encodedFile, unordered_map<int, string> lookupTable, huffnode *node);

private:
	int letterFreq[257];
	unordered_map<int, string>* lookupTable;
	huffnode* root;
	string msgFile;	// The file location of the orginal uncompressed message
	void CreateLookupTable(huffnode* node, string bit,unordered_map<int, string> lookupTable);
};

