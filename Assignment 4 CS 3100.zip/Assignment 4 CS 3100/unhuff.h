#pragma once
#include <iostream>
#include <fstream>
#include<string>
#include<vector>
#include<queue>
#include<unordered_map>
using namespace std;

#include "bitops.h"
#include "huffnode.h"
class unhuff
{
public:
	unhuff(string encodedfile);
	~unhuff();
private:
	huffnode* root;
	void ConstructHuffTree(ibstream& input);
	void DecodeMsg(ibstream& input);
};