#include "unhuff.h"

struct compare
{
	bool operator()(const huffnode* l, const huffnode* r)
	{
		return l->weight > r->weight;
	}
};

unhuff::unhuff(string encodedfile)
{
	ibstream input;
	input.open(encodedfile);

	ConstructHuffTree(input);
	DecodeMsg(input);
}


unhuff::~unhuff()
{
}

void unhuff::ConstructHuffTree(ibstream& input)
{
	priority_queue<huffnode*, vector<huffnode*>, compare>* pq = new priority_queue<huffnode*, vector<huffnode*>, compare>;

	int letterFreq[257];

	// Read the input stream and get the frequencies
	// HINT: input.readbits(BITS_PER_INT, letterFreq[i]); // This reads a single int from the file into letterFreq[i]

    // Build the tree here.  It will be identical to the huff tree building code.
	while (pq->size() != 1)
	{
		huffnode* testNode1 = new huffnode();

		testNode1 = pq->top();

		pq->pop();
		huffnode* testNode2 = new huffnode();
		testNode2 = pq->top();

		pq->pop();

		// peek at the top value

		huffnode*combinedNode = new huffnode();
		combinedNode->letter = NOT_A_LETTER;

		combinedNode->weight = testNode1->weight + testNode2->weight;

		if (testNode1->letter < testNode2->letter)
		{
			combinedNode->zero = testNode1;
			combinedNode->one = testNode2;
		}
		else
		{
			combinedNode->zero = testNode1;
			combinedNode->one = testNode2;

		}
		pq->push(combinedNode);

	}
}

// Assumes the tree has been constructed
void unhuff::DecodeMsg(ibstream& input)
{
	int bit;
	huffnode* node = root;

	while (true) {

		if (!input.readbits(1, bit)) {
			// something...
		}

		if (bit == 1) {
			// something...
		}
		else if (bit == 0 ) {
			// something...
		}
		
		if (huffnode::isLeaf(node)) {
			// something else...
		}
	}
}
